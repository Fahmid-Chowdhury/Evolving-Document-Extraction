ওরেজিস্টার্ড নং ডি এ-১

বাংলাদেশ

![Emblem of Bangladesh featuring a map of Bangladesh, surrounded by the text 'গণপ্রজাতন্ত্রী বাংলাদেশ সরকার' (Government of the People's Republic of Bangladesh) and stars.](ae472eab6cf80f949c5031e675c2fd26_3_img.webp)

গেজেট

অতিরিক্ত সংখ্যা  
কর্তৃপক্ষ কর্তৃক প্রকাশিত

মঙ্গলবার, অক্টোবর ১২, ২০১০

গণপ্রজাতন্ত্রী বাংলাদেশ সরকার  
অর্থ মন্ত্রণালয়  
অভ্যন্তরীণ সম্পদ বিভাগ  
জাতীয় রাজস্ব বোর্ড  
(আয়কর)  
প্রজ্ঞাপন

তারিখ, ২৫ আশ্বিন ১৪১৭ বঙ্গাব্দ/১০ অক্টোবর ২০১০ খ্রিস্টাব্দ

এস, আর, ও নং ৩৪২-আইন/আয়কর/২০১০।—Income-tax Ordinance, 1984 (Ord. XXXVI of 1984) এর section 185 এ প্রদত্ত ক্ষমতাবলে জাতীয় রাজস্ব বোর্ড, Income Tax Rules, 1984 এর নিম্নরূপ অধিকতর সংশোধনের প্রস্তাব করিয়া এতদ্বারা উহা প্রাক-প্রকাশ করিল, যথা ৪—

উপরি-উক্ত Rules এর rule 59A এর পরিবর্তে নিম্নরূপ rule 59A প্রতিস্থাপিত হইবে; যথা ৪—

**“59A. Form of application to be made by a company for exemption from tax under section 46B of the Ordinance.—**

(1) An application under clause (e) of sub-section (4) of section 46B of the Ordinance for approval for the purposes of that section in respect of an industrial undertaking, tourist industry or physical infrastructure facility shall be made in the following form, in duplicate, duly signed and verified by the Managing Director or Director of the company, namely :—

Form of Application under section 46B of the Income-tax Ordinance, 1984 (XXXVI of 1984).

(i) Name of the company :  
(ii) Date of incorporation of the company :

( ৯৩২৩ )

মূল্য ৪ টাকা ৪.০০৯৩২৪বাংলাদেশ গেজেট, অতিরিক্ত, অক্টোবর ১২, ২০১০

---

- (iii) Location of its registered office (with full address) :
- (iv) Location of the industrial undertaking/tourist industry/physical infrastructure facility :
- (v) Tax Identification Number (TIN) and name of the Zone of Commissioner of Taxes and the Circle of Deputy Commissioner of Taxes under whose jurisdiction the company is assessed or will be assessed :
- (vi) Date of opening of the letter of credit :
- (vii) Date on which the machinery installed was ready for production/operation/service :
- (viii) Date or dates on which the industrial undertaking/tourist industry/physical infrastructure facility for which approval is sought stated—
  - (a) trial production/operation/service :
  - (b) commercial production/operation/service :
- (ix) Date on which the issued, subscribed and paid up capital of the company reached the figure of taka one lakh :
- (x) The present paid up capital of the company :
- (xi) Authorized capital of the company :
- (xii) Amount of share capital issued :
- (xiii) Amount of investment involved in setting up and running the industrial undertaking/tourist industry/physical infrastructure facility for which approval is sought :
- (xiv) Minimum number of employees required to be engaged in one shift:
- (xv) Whether the industrial undertaking/tourist industry/physical infrastructure facility uses electric energy or gas (the date on which the electricity or gas connection was physically given should be mentioned) :
- (xvi) Whether the industrial undertaking/tourist industry/physical infrastructure facility obtains a clearance certificate for the relevant income year from the Directorate of Environment :
- (xvii) Value Added Tax (VAT) Registration Number/Turn over tax Number :
- (xviii) Exact nature of business of the industrial undertaking/tourist industry/physical infrastructure facility and in case of an industrial undertaking, the list of items manufactured :
- (xix) Raw materials to be used in the industrial undertaking :
- (xx) Whether any building, plant or machinery has been taken on rent or lease for the industrial undertaking/tourist industry/physical infrastructure facility : if so, detailed description shall be given :বাংলাদেশ গেজেট, অতিরিক্ত, অক্টোবর ১২, ২০১০

৯৩২৫

(xxi) Names and addresses of the Managing Director and Directors of the company with particulars of their holdings and interest in the company and other companies or enterprises :

Signature of the  
Managing Director/Director.

Date.....

**Verification**

I,.....do hereby solemnly affirm that the information given above is correct and complete.

Signature of the  
Managing Director/Director.

\* Delete whichever is inapplicable.]

(2) The application shall be accompanied by—

- (i) an attested copy of certificate of incorporation;
- (ii) a certificate of commencement of business;
- (iii) an attested copy of the Memorandum and Articles of Association of the company;
- (iv) in case the company has already commenced business, certified copy of the audited balance sheet and profit and loss accounts for the period for which the accounts have been prepared (for an incomplete year trial balance may be submitted);
- (v) in case of industrial undertaking/tourist industry/physical infrastructure facility for which approval is sought has been acquired for another party, an attested copy of the agreement between the applicant company and the seller enter into for the acquisition of the industrial undertaking/tourist industry/physical infrastructure with list and value of assets acquire;
- (vi) a certificate to the effect that the industrial undertaking/tourist industry/physical infrastructure facility has not applied or shall not apply for accelerated, depreciation allowance under paragraph 7 or 7A of the Third Schedule to the Ordinance in the following form, namely:—

“I hereby certify that no application in respect of the industrial undertaking/tourist industry/physical infrastructure facility..... (name of the undertaking etc.) has been made or shall be made to the Board for, and that the said industrial undertaking/tourist industry/physical infrastructure facility has not been allowed, accelerated depreciation allowance under paragraph 7 or 7A of the Third Schedule to the Ordinance for any period.

Place.....  
Date.....

Signature of the  
Managing Director/Director]৯৩২৬বাংলাদেশ গেজেট, অতিরিক্ত, অক্টোবর ১২, ২০১০

(3) On receipt of an application under sub-rule (1), the Board may make such enquires as it may consider necessary and may call for such further particulars as it may think fit.

(4) If the Board is satisfied that the company setting up the industrial undertaking or the tourist industry or the physical infrastructure facility or the expansion unit thereof is one which should be approved for the purposes of section 46B of the Ordinance, it shall make an order to that effect and send a copy thereof to the company.

(5) Where the Board has passed an order in writing refusing to approve the industrial undertaking or the tourist industry or the physical infrastructure facility or the expansion unit thereof for purposes of section 46B of the Ordinance, the person aggrieved by such order may make an application in writing to the Chairman of the Board for review, who will either himself review the order or may constitute a committee consisting of three Members of the Board to review the same. The review order shall be passed after giving the applicant an opportunity of being heard and the decision of the review shall be final and conclusive.”।

২। উপরি-উক্ত সংশোধনী প্রস্তুত সম্পর্কে কাহারও কোন আপত্তি ও পরামর্শ থাকিলে সংশ্লিষ্ট ব্যক্তিকে উহা, এই প্রস্তাবন সরকারী গেজেটে প্রকাশের তারিখ হইতে অনধিক ১৫ (পনের) দিনের মধ্যে, নিম্নস্বাক্ষরকারীর নিকট পৌছাইবার জন্য অনুরোধ করা যাইতেছে এবং উক্ত সময়ের মধ্যে সংশোধনী প্রস্তাব সম্পর্কে কোন আপত্তি ও পরামর্শ পাওয়া গেলে জাতীয় রাজস্ব বোর্ড উহা বিবেচনাক্রমে প্রস্তাবিত সংশোধনী চূড়ান্ত করিবে। উক্ত সময়ের মধ্যে কোন পরামর্শ বা আপত্তি পাওয়া না গেলে এইরূপ প্রাক-প্রকাশ চূড়ান্ত প্রকাশ বলিয়া গণ্য করা হইবে।

জাতীয় রাজস্ব বোর্ডের আদেশক্রমে

আমিনুর রহমান  
সদস্য (আয়কর নীতি)।

মোঃ মাছুম খান (উপ-সচিব), উপ-পরিচালক, বাংলাদেশ সরকারি মুদ্রণালয়, ঢাকা কর্তৃক মুদ্রিত।

মোঃ মজিবুর রহমান (যুগ্ম-সচিব), উপ-পরিচালক, বাংলাদেশ ফরম ও প্রকাশনা অফিস,  
তেজগাঁও, ঢাকা কর্তৃক প্রকাশিত। web site: www.bgpress.gov.bd